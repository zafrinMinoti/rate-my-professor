from selenium import webdriver
from bs4 import BeautifulSoup

class WebConnection:
    _ROOT = 'http://www.ratemyprofessors.com/ShowRatings.jsp?tid='
    phantomjs_thinkpad = '/home/zafrin/Programs'
    phantomjs_aws = '/home/ec2-user'

    def __init__(self, prof_id):
        self._prof_id = prof_id
        self.url = WebConnection._ROOT+str(self.prof_id)

        try:
            self.driver = webdriver.PhantomJS(
                executable_path=phantomjs_thinkpad+'/phantomjs-2.1.1-linux-x86_64/bin/phantomjs')
        except:
            self.driver = webdriver.PhantomJS(
                executable_path=phantomjs_aws+'/phantomjs-2.1.1-linux-x86_64/bin/phantomjs')
        finally:
            self.driver.get(self.url)
            self.soup = BeautifulSoup(self.driver.page_source, 'lxml')


    @property
    def prof_id(self):
        return self._prof_id